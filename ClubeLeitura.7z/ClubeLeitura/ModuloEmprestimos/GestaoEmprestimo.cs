﻿using ClubeLeitura.ModuloAmigos;
using ClubeLeitura.ModuloRevista;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClubeLeitura.ModuloEmprestimos
{
    public class GestaoEmprestimo
    {
        public void EmprestimoMenu()
        {
            int opcaoEmprestimo;

            do
            {
                Console.Clear();
                Console.WriteLine("\nMenu empréstimo\n [1] Cadastrar \n [2] Visualizar \n [3] Visualizar empréstimos em aberto \n [4] Sair \n");
                opcaoEmprestimo = int.Parse(Console.ReadLine());

                switch (opcaoEmprestimo)
                {
                    case 1:
                        Cadastrar();
                        break;
                    case 2:
                        VisualizarEmprestimosMes();
                        break;
                    case 3:
                        VisualizarEmprestimosEmAberto();
                        break;
                }
            } while (opcaoEmprestimo != 4);
        }
        private void Cadastrar()
        {
            InfoAmigos.MostrarAmigos();
            Console.WriteLine("Digite o ID do amigo: ");
            int idAmigo = int.Parse(Console.ReadLine());
            Amigos amigo = InfoAmigos.EncontrarAmigoPeloId(idAmigo);
            InfoRevista.MostrarRevistas();

            Console.WriteLine("Digite o ID da revista: ");
            int idRevista = int.Parse(Console.ReadLine());
            Revista revista = InfoRevista.EncontrarRevistaPeloId(idRevista);

            Console.WriteLine("Data do empréstimo: ");
            string dataAbertura = Console.ReadLine();

            Console.WriteLine("Data devolução: ");
            string dataDevolucao = Console.ReadLine();

            bool validacaoEmprestimo = InfoEmprestimo.VerificarRevistaAmigo(idAmigo);
            if (validacaoEmprestimo)
            {
                Console.WriteLine("Somente uma revista por vez.");
                Console.ReadLine();
                return;
            }

            Emprestimo emprestimo = new Emprestimo(amigo, revista, dataAbertura, dataDevolucao);
            InfoEmprestimo.Cadastrar(emprestimo);
        }
        private void VisualizarEmprestimosMes()
        {
            bool validacaoCaixas = InfoRevista.ValidarListaRevista();
            if (validacaoCaixas)
                return;
            InfoEmprestimo.EmprestimosMesAtual();
        }
        private void VisualizarEmprestimosEmAberto()
        {
            bool validacaoCaixas = InfoRevista.ValidarListaRevista();
            if (validacaoCaixas)
                return;
            InfoEmprestimo.EmprestimosEmAberto();
        }

    }
}
